#!/bin/bash

if  test -n $1 ; then

	echo "Start converting SPD DUMP to HEX..."
	SPDNAME=`echo $1 | awk -F.rom '{print $1}'`
	SPDEXT=".hex"
	cat $1 | sed 's/^0....0//' | grep -v "^$" | sed -e 's/^ //g' | sed -e ':a;N;$!ba;s/\n/ /g' | sed -e 's/ /\n/g' | head -c 1535 >  $SPDNAME""$SPDEXT
	echo "Done!"
else 
	echo "There is no input SPD DUMP file"
fi
