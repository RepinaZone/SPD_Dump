#!/bin/bash

#sudo modprobe ee1004
#sudo modprobe -r eeprom
#echo ee1004 0x50 > /sys/bus/i2c/devices/i2c-1/new_device
#sudo bash 'echo ee1004 0x50' > /sys/bus/i2c/devices/i2c-1/new_device
#od -Ax -t x1 -v /sys/bus/i2c/drivers/ee1004/1-0050/eeprom > 16Gb-ECC.hex

sudo i2cdetect -y 0
sudo modprobe -r eeprom
sudo modprobe ee1004
sudo i2cdetect -y 0
sudo i2cdetect -y 1
sudo bash 'echo ee1004 0x50' > /sys/bus/i2c/devices/i2c-1/new_device
sudo bash -c 'echo ee1004 0x50' > /sys/bus/i2c/devices/i2c-1/new_device
sudo bash -c "echo ee1004 0x50" > /sys/bus/i2c/devices/i2c-1/new_device
sudo bash -c "echo ee1004 0x50 > /sys/bus/i2c/devices/i2c-1/new_device"
sudo bash -c "echo ee1004 0x52 > /sys/bus/i2c/devices/i2c-1/new_device"
decode-dimms
od -Ax -t x1 -v /sys/bus/i2c/drivers/ee1004/1-0050/eeprom
od -Ax -t x1 -v /sys/bus/i2c/drivers/ee1004/1-0052/eeprom
od -Ax -t x1 -v /sys/bus/i2c/drivers/ee1004/1-0052/eeprom >8Gb-0.hex
od -Ax -t x1 -v /sys/bus/i2c/drivers/ee1004/1-0052/eeprom >8Gb-1.hex
od -Ax -t x1 -v /sys/bus/i2c/drivers/ee1004/1-0050/eeprom >8Gb-0.hex
