#!/bin/bash

mkdir -p ./SPDs

# I2C Bus Number check
I2CBUSID=`i2cdetect -r -y -l | grep I801 | awk '{print $1}' | sed 's/i2c-//'`
echo -e "I2C Bus number is:" $I2CBUSID
# End I2C Bus Number check

# EEPROM module unload/load section
echo -e "Unloading eeprom kernel module..."
sudo modprobe -r eeprom
echo "Done!"


echo -e "Checking if ee1004 kernel module is loaded..."
CHECK_EE1004_IS_LOADED=`lsmod | grep ee1004 | awk '{print $1}'`
if [[ -z $CHECK_EE1004_IS_LOADED ]]; then
	echo -e "Loading ee1004 kernel module..."
	sudo modprobe ee1004
	echo -e "Setting Bank0 (0x50)..."
	sudo bash -c 'echo ee1004 0x50' > /sys/bus/i2c/devices/i2c-1/new_device
else
	echo -e "ee1004 kernel module is already loaded"
fi
echo -e "Done!"
# End of EEPROM module unload/load section

RAM_VENDOR=`decode-dimms | grep "Module Manufacturer" | awk '{print $3}'`
RAM_PARTNUMBER=`decode-dimms | grep "Part Number" | awk '{print $3}'`
RAM_SIZE_MB=`decode-dimms | grep Size | awk '{print $2}'`
RAM_SIZE_GB=$[ RAM_SIZE_MB / 1024 ]

#echo $RAM_VENDOR
#echo $RAM_PARTNUMBER
#echo $RAM_SIZE_MB "Mb"
#echo $RAM_SIZE_GB "Gb"

#echo $RAM_VENDOR"-"$RAM_PARTNUMBER"-"$RAM_SIZE_GB"Gb.hex"

# Dump SPD section
od -Ax -t x1 -v /sys/bus/i2c/drivers/ee1004/1-0050/eeprom | sed 's/^0....0//' | grep -v "^$" | sed -e 's/^ //g' | sed -e ':a;N;$!ba;s/\n/ /g' | sed -e 's/ /\n/g' | head -c 1535 > ./SPDs/$RAM_VENDOR"-"$RAM_PARTNUMBER"-"$RAM_SIZE_GB"Gb.hex"
# End of Dump SPD section

# Check SPD dump
ls -la ./SPDs/$RAM_VENDOR"-"$RAM_PARTNUMBER"-"$RAM_SIZE_GB"Gb.hex"
# End Check SPD dump
